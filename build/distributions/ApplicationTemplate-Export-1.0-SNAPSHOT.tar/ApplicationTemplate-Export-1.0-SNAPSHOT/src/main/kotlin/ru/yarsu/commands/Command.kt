package ru.yarsu.commands

interface Command {
    fun execute()
}
